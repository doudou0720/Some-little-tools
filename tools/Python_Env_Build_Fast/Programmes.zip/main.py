import easygui

import os

print("Music163 网易云音乐下载")
print("请确认你已将MS Edge升级为最新版本")

input("确认并继续 请回车\n>>")